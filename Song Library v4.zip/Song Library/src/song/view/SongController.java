package song.view;

import java.util.Optional;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SongController extends SortByName {
	@FXML ListView<Song> listView;
	@FXML Button add;
	@FXML Button edit;
	@FXML Button delete;
	@FXML TextField name;
	@FXML TextField artist;
	@FXML TextField album;
	@FXML TextField year;
	
	private ObservableList<Song> songList;
	
	public void start(Stage mainStage) {
		// create an ObservableList
		// from an ArrayList
		songList = FXCollections.observableArrayList();
		songList.addAll(ReadData.getSongList());
		
		
		listView.setItems(songList);
		
		
		//selects first item in song list and displays name and artist in details
		if (songList!=null && !songList.isEmpty()) {
			listView.getSelectionModel().clearAndSelect(0);
			Song getSong = listView.getSelectionModel().getSelectedItem();
			showDetails(getSong);
		}
		// set listener for the items
		listView
			.getSelectionModel()
			.selectedIndexProperty()
			.addListener(
				(obs,oldVal,newVal) ->
					showDetails(listView.getSelectionModel().getSelectedItem()));
		
		
		
	}
	
	private void showDetails(Song song) {
		if (song!=null) {
			name.setText(song.getSong());
			artist.setText(song.getArtist());
			album.setText(song.getAlbum() != null ? song.getAlbum() : "");
			year.setText(song.getAlbum() != null ? Long.toString(song.getYear()) : "");
		}
	}
	
	public void delete(ActionEvent e) {
		String header = "Are you sure you want to delete selected item";
		String title = "Delete Confirmation";
		boolean result = confirmation(header,title);
		if (result==true) {
			int index = listView.getSelectionModel().getSelectedIndex();
			if (songList.size()==1) { //removing only item in songList, don't show details
				songList.remove(index);
				name.setText("");
				artist.setText("");
				album.setText("");
				year.setText("");
			}
			else if (index==songList.size()-1) { //removing last item in songList, select previous
				listView.getSelectionModel().selectPrevious();
				songList.remove(index);
			}
			else { //
				listView.getSelectionModel().selectNext();
				songList.remove(index);
			}
		}
	}
	
	public void add(ActionEvent e) {
		String header = "Are you sure you want to add to the song library";
		String title = "Add Confirmation";
		boolean result = confirmation(header,title);
		if (checkErrors()) {
			return;
		}
		if (result==true) {
			Song newSong = new Song(name.getText().strip(),artist.getText().strip());
			if(!album.getText().isBlank()) {
				newSong.setAlbum(album.getText().strip());
			}
			if(!year.getText().isBlank()) {
				newSong.setYear(Long.parseLong(year.getText().strip()));
			}
			
			
			
			if (songList.contains(newSong)==true) { //duplicate song
				error(); //displays error pop-up
			}
			else { //adds it to the appropriate spot in songList
				for (int i=0; i<songList.size(); i++) {
					if (compare(newSong,songList.get(i)) < 0) {
						songList.add(i, newSong);
						listView.getSelectionModel().select(i);
						break;
					}
					else if (i==songList.size()-1) {
						songList.add(newSong);
						listView.getSelectionModel().select(i+1);
						break;
					}
					else {
						continue;
					}
				}
				if (songList.size()==0) { //if you're adding to an empty songList
					songList.add(newSong);
					listView.getSelectionModel().select(0);
				}
			}
		}
	}
	
	public boolean checkErrors() {
		if (name.getText()==null || name.getText().equals("") || name.getText().contains("|") ||
			artist.getText()==null || artist.getText().equals("") || artist.getText().contains("|")) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Invalid Input");
			alert.setHeaderText("Make sure to populate Name and Artist fields.\nDon't use '|' character.");
			alert.showAndWait();
			return true;
		}
		return false;
	}
	
	//displays confirmation dialog box
	//returns true if user hits yes, false if user hits cancel
	public boolean confirmation(String header, String title) {
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle(title);
		alert.setHeaderText(header);
		Optional<ButtonType> result = alert.showAndWait();
		if (result.get()==ButtonType.OK) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public void error() {
		Alert alert = new Alert(AlertType.ERROR);
		alert.setTitle("Duplicate Song");
		alert.setHeaderText("Song already exists in the library");
		alert.showAndWait();
	}
	
	public ObservableList<Song> getObservableList(){
		return this.songList;
	}
	
}
