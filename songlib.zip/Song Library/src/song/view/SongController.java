package song.view;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SongController {
	@FXML ListView<String> listView;
	@FXML Button add;
	@FXML Button edit;
	@FXML Button delete;
	@FXML TextField name;
	@FXML TextField artist;
	@FXML TextField album;
	@FXML TextField year;
	
	private ObservableList<String> obsList;
	
	public void start(Stage mainStage) {
		// create an ObservableList
		// from an ArrayList
		obsList = FXCollections.observableArrayList(
				"Blinding Lights | The Weeknd",
				"Hit em Up | Tupac",
				"Rocket Man | Elton John");
		listView.setItems(obsList);
		
		//selects first item in song list and displays name and artist in details
		if (obsList!=null && !obsList.isEmpty()) {
			listView.getSelectionModel().clearAndSelect(0);
			String getSong = "";
			getSong = listView.getSelectionModel().getSelectedItem();
			showDetails(getSong);
		}
		// set listener for the items
		listView
			.getSelectionModel()
			.selectedIndexProperty()
			.addListener(
				(obs,oldVal,newVal) ->
					showDetails(listView.getSelectionModel().getSelectedItem()));
	}
	
	private void showDetails(String getSong) {
		if (!getSong.isEmpty()) {
			int divider = getSong.indexOf("|");
			String songName = getSong.substring(0, divider);
			String artistName = getSong.substring(divider+1, getSong.length());
			name.setText(songName);
			artist.setText(artistName);
		}
	}
	
	public void delete(ActionEvent e) {
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setContentText("Delete");
		alert.showAndWait();
	}
	
	/*private void showItem(Stage mainStage) {
		Alert alert =
			new Alert(AlertType.INFORMATION);
		alert.initOwner(mainStage);
		alert.setTitle("List Item");
		alert.setHeaderText(
			"Selected list item properties");
		String content = "Index: " +
			listView.getSelectionModel()
				.getSelectedIndex() +
			"\nValue: " +
			listView.getSelectionModel()
				.getSelectedItem();
			alert.setContentText(content);
			alert.showAndWait();
	}*/
}
