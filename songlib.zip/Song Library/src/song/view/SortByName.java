//Karl Sequeira
//Ibrahim Khajanchi

package song.view;

import java.util.Comparator;

public class SortByName implements Comparator<Song> {
	
	public int compare(Song a, Song b) {
		//used toLowerCase() to make it case INsensitive
		if(a.getSong().toLowerCase().equals(b.getSong().toLowerCase())) {
			return(a.getArtist().toLowerCase().compareTo(b.getArtist().toLowerCase()));
		}
		return(a.getSong().toLowerCase().compareTo(b.getSong().toLowerCase()));
	}
}
