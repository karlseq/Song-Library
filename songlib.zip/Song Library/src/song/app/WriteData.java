//Karl Sequeira
//Ibrahim Khajanchi

package song.app;

import java.io.FileWriter;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import javafx.collections.ObservableList;
import song.view.Song;

public class WriteData {
	
	@SuppressWarnings("unchecked")
	public static void writeData(ObservableList<Song> songList) {
		 JSONArray jsonSongList = new JSONArray();
		 
		//iterate thru list and add song to JSONobject
		for(Song s : songList) {
			JSONObject songDetails = new JSONObject();
			
			songDetails.put("songName", s.getSong());
			songDetails.put("artist", s.getArtist());
			songDetails.put("album", s.getAlbum());
			songDetails.put("year", s.getYear());
			
			JSONObject songObject = new JSONObject();
			songObject.put("song", songDetails);
			
			jsonSongList.add(songObject);

		}
		
		//write it to the file
		try(FileWriter file = new FileWriter("text/songData.json")){
			
			file.write(jsonSongList.toJSONString());
			file.flush();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	}
}
