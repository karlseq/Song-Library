package song.view;

public class Song {
	private String song, artist;
	
	public Song(String song, String artist) {
		this.song = song; this.artist = artist;
	}
	
	public String getSong() {
		return this.song;
	}
	
	public String getArtist() {
		return this.artist;
	}
	
	public boolean equals(Object obj) {
		if (obj==null || this.getClass()!=obj.getClass()) {
			return false;
		}
		Song s1 = (Song)obj;
		
		//makes fields case INsensitive for comparison
		String ogName = this.song;
		String ogArtist = this.artist;
		
		return ogName.toLowerCase().strip().equals(s1.song.toLowerCase().strip()) && 
				ogArtist.toLowerCase().strip().equals(s1.artist.toLowerCase().strip());
	}
	
	public String toString() {
		return (this.song + " | " + this.artist);
	}
	
}
