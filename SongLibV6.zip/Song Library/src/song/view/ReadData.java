package song.view;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class ReadData {

	public static ArrayList<Song> songList;
	
	@SuppressWarnings("unchecked")
	public static ArrayList<Song> getSongList() {
		
		songList = new ArrayList<>();
		JSONParser parser = new JSONParser();
		
		File file = new File("text/songData.json");
		if(file.length() == 0) {
			return null;
		}
		try(FileReader reader = new FileReader("text/songData.json")){
			
			Object obj = parser.parse(reader);
			JSONArray list = (JSONArray) obj;
			
			list.forEach(song -> parseSongObject((JSONObject) song));
			
		}
		catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return songList;
	}
	
	public static void parseSongObject(JSONObject song) {
		JSONObject songObject = (JSONObject) song.get("song");
		
		String songName = (String) songObject.get("songName");
		String artist = (String) songObject.get("artist");
		
		Song s = new Song(songName, artist);

		if(songObject.containsKey("album")) {
			s.setAlbum((String) songObject.get("album"));
		}
		if(songObject.containsKey("year")){
			s.setYear((long) songObject.get("year"));
		}
		
		songList.add(s);
	}

}
