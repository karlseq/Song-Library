package song.view;

import java.util.Comparator;

public class SortByName implements Comparator<Song> {
	
	public int compare(Song a, Song b) {
		if(a.getSong().equals(b.getSong())) {
			return(a.getArtist().compareTo(b.getArtist()));
		}
		return(a.getSong().compareTo(b.getSong()));
	}
}
