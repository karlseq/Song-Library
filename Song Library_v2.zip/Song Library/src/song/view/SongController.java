package song.view;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SongController {
	@FXML ListView<Song> listView;
	@FXML Button add;
	@FXML Button edit;
	@FXML Button delete;
	@FXML TextField name;
	@FXML TextField artist;
	@FXML TextField album;
	@FXML TextField year;
	
	private ObservableList<String> obsList;
	private ObservableList<Song> songList;
	
	public void start(Stage mainStage) {
		// create an ObservableList
		// from an ArrayList
		
		songList = FXCollections.observableArrayList();
		songList.add(new Song("Blinding Lights", "The Weeknd"));
		songList.add(new Song("Hit em Up", "Tupac"));
		songList.add(new Song("Rocket Man", "Elton John"));

		
		listView.setItems(songList);
		
		
		//selects first item in song list and displays name and artist in details
		if (obsList!=null && !obsList.isEmpty()) {
			listView.getSelectionModel().clearAndSelect(0);
			Song getSong = listView.getSelectionModel().getSelectedItem();
			showDetails(getSong);
		}
		// set listener for the items
		listView
			.getSelectionModel()
			.selectedIndexProperty()
			.addListener(
				(obs,oldVal,newVal) ->
					showDetails(listView.getSelectionModel().getSelectedItem()));
	}
	
	private void showDetails(Song song) {
		if (song != null) {
			/*
			int divider = getSong.indexOf("|");
			String songName = getSong.substring(0, divider);
			String artistName = getSong.substring(divider+1, getSong.length());
			*/
			
			name.setText(song.getSong());
			artist.setText(song.getArtist());
		}
	}
	
	public void delete(ActionEvent e) {
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setContentText("Delete");
		alert.showAndWait();
	}
	
	/*
	private void showItem(Stage mainStage) {
		Alert alert =
			new Alert(AlertType.INFORMATION);
		alert.initOwner(mainStage);
		alert.setTitle("List Item");
		alert.setHeaderText(
			"Selected list item properties");
		String content = "Index: " +
			listView.getSelectionModel()
				.getSelectedIndex() +
			"\nValue: " +
			listView.getSelectionModel()
				.getSelectedItem();
			alert.setContentText(content);
			alert.showAndWait();
	}
	*/
}
