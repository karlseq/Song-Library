package song.view;


public class Song{
	private String song, artist;
	
	public Song(String song, String artist) {
		this.song = song; this.artist = artist;
	}
	
	public String getSong() {
		return this.song;
	}
	
	public String getArtist() {
		return this.artist;
	}
	
	public String toString() {
		return (this.song + " | " + this.artist);
	}
	
}
